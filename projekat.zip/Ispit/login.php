<?php
session_start();
require 'includes/db.php';

// Provera da li je korisnik već prijavljen
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['is_admin']) {
        header('Location: admin.php');
    } else {
        header('Location: user.php');
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Provera u tabeli "users"
    $stmt = $conn->prepare('SELECT * FROM users WHERE username = :username');
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Ako korisnik nije pronađen u "users", proveri u "admins"
    if (!$user) {
        $stmt = $conn->prepare('SELECT * FROM admins WHERE username = :username');
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];

        // Provera admin statusa
        if (isset($user['is_admin']) || $stmt->queryString === 'SELECT * FROM admins WHERE username = :username') {
            $_SESSION['is_admin'] = true; // Admin korisnik
            header('Location: admin.php');
        } else {
            $_SESSION['is_admin'] = false; // Obični korisnik
            header('Location: user.php');
        }
        exit;
    } else {
        $error_message = "Pogrešno korisničko ime ili lozinka";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
    <style>
        .login-container { padding-right: 40px; }
    </style>
</head>
<body style="background-image: url('/Ispit/uploads/slika_login.jpg'); background-size: cover;">
    <div class="login-container" style="color: red;"> <!-- Dodato inline CSS za crvenu boju -->
        <h2 style="color: red;">Prijava</h2> <!-- Boja slova crvena za naslov -->
        <?php if (isset($error_message)): ?>
            <p class="error" style="color: red;"><?= htmlspecialchars($error_message) ?></p> <!-- Boja slova crvena za grešku -->
        <?php endif; ?>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="Korisničko ime" required style="color: red;"> <!-- Crvena boja teksta -->
            <input type="password" name="password" placeholder="Lozinka" required style="color: red;"> <!-- Crvena boja teksta -->
            <button type="submit" style="color: red;">Prijavi se</button> <!-- Crvena boja teksta za dugme -->
        </form>
    </div>
</body>
</html>
