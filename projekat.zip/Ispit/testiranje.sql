-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2024 at 12:33 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testiranje`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password_hash`, `email`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$X5OZ4g6KpX4YqBD.cyLwp.AhlBx0NocKQN.daSwGl.xfeoDYYfft.', 'admin@example.com', '2024-11-25 09:15:35', '2024-11-25 09:21:49');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_changes`
--

CREATE TABLE `pending_changes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `pending_changes`
--

INSERT INTO `pending_changes` (`id`, `user_id`, `field_name`, `old_value`, `new_value`, `status`, `created_at`) VALUES
(1, 1, 'name', 'John', 'John', 'approved', '2024-11-26 16:51:55'),
(2, 1, 'surname', 'Doe', 'Doe', 'approved', '2024-11-26 16:51:55'),
(3, 1, 'jmbg', '1234567890123', '1234567890123', 'approved', '2024-11-26 16:51:55'),
(4, 1, 'fitpass_number', 'AB12345', '12321312', 'approved', '2024-11-26 16:51:55'),
(5, 1, 'membership_valid_until', '2024-12-31', '2024-12-31', 'approved', '2024-11-26 16:51:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `jmbg` char(13) NOT NULL,
  `fitpass_number` varchar(20) DEFAULT NULL,
  `membership_valid_until` date DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `email`, `name`, `surname`, `jmbg`, `fitpass_number`, `membership_valid_until`, `blocked`, `created_at`, `updated_at`) VALUES
(1, 'user', '$2y$10$X5OZ4g6KpX4YqBD.cyLwp.AhlBx0NocKQN.daSwGl.xfeoDYYfft.', 'user@example.com', 'John', 'Doe', '1234567890123', 'AB12345', '2024-12-31', 0, '2024-11-25 09:15:35', '2024-11-25 09:32:03'),
(3, 'pera123', '', 'pera@gmail.com', 'Petar', 'Petrovic', '13124331241', '143441', '2024-11-15', 0, '2024-11-26 23:05:38', '2024-11-26 23:06:58'),
(5, 'rwhite654', '', 'rwhite654@example.com', 'Rachel', 'White', '5678961234567', '90123', '2027-05-02', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(6, 'jrichards', '', 'jrichards@example.com', 'James', 'Richards', '6786012345678', '23456', '2021-11-01', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(7, 'ltaylor987', '', 'ltaylor987@example.com', 'Laura', 'Taylor', '7896123456789', '34567', '2023-02-15', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(8, 'mclark112', '', 'mclark112@example.com', 'Mark', 'Clark', '8901234667890', '45678', '2025-08-25', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(9, 'bwilliams22', '', 'bwilliams22@example.com', 'Ben', 'Williams', '9612345678901', '56789', '2024-04-10', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(10, 'lharris89', '', 'lharris89@example.com', 'Linda', 'Harris', '0123656789012', '67890', '2023-11-09', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(11, 'jmartin555', '', 'jmartin555@example.com', 'Jason', 'Martin', '1264567898765', '78901', '2024-12-25', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(12, 'pthomas321', '', 'pthomas321@example.com', 'Paul', 'Thomas', '2346668907654', '89012', '2025-03-31', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(13, 'gsanchez678', '', 'gsanchez678@example.com', 'Gabriela', 'Sanchez', '6456789012345', '90123', '2024-11-20', 0, '2024-11-26 23:26:26', '2024-11-26 23:29:48'),
(14, 'jmoore432', '', 'jmoore432@example.com', 'John', 'Moore', '4567890123756', '12345', '2025-11-05', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(15, 'ewright234', '', 'ewright234@example.com', 'Emily', 'Wright', '5678907234567', '23456', '2026-01-12', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(16, 'abaker987', '', 'abaker987@example.com', 'Adam', 'Baker', '6789012345778', '34567', '2024-06-14', 0, '2024-11-26 23:26:26', '2024-11-26 23:28:52'),
(17, 'zgreen221', '', 'zgreen221@example.com', 'Zoe', 'Green', '7890123456779', '45678', '2027-09-15', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(18, 'jallen888', '', 'jallen888@example.com', 'Jack', 'Allen', '8901234567790', '56789', '2023-12-12', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(19, 'tperez654', '', 'tperez654@example.com', 'Tom', 'Perez', '9012345678971', '67890', '2024-05-22', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(20, 'bjackson987', '', 'bjackson987@example.com', 'Brian', 'Jackson', '0127456789012', '78901', '2025-03-02', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(21, 'nwalker123', '', 'nwalker123@example.com', 'Nathan', 'Walker', '1234577892345', '89012', '2026-07-14', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(22, 'jmoore888', '', 'jmoore888@example.com', 'Julie', 'Moore', '2345678908234', '90123', '2024-10-04', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(23, 'dgarcia776', '', 'dgarcia776@example.com', 'David', 'Garcia', '3456788012345', '23456', '2025-02-17', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(24, 'hpatterson', '', 'hpatterson@example.com', 'Hannah', 'Patterson', '4587890123456', '34567', '2026-04-01', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(25, 'sgomez789', '', 'sgomez789@example.com', 'Samantha', 'Gomez', '5678908234567', '45678', '2023-07-23', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(26, 'tprice123', '', 'tprice123@example.com', 'Thomas', 'Price', '6789012395678', '56789', '2024-08-30', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(27, 'lwilson456', '', 'lwilson456@example.com', 'Lily', 'Wilson', '7890123056789', '67890', '2025-11-11', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(28, 'kscott654', '', 'kscott654@example.com', 'Kevin', 'Scott', '8901234560890', '78901', '2023-04-19', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(29, 'rwright123', '', 'rwright123@example.com', 'Robert', 'Wright', '9012305678901', '89012', '2027-05-14', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(30, 'bhill432', '', 'bhill432@example.com', 'Ben', 'Hill', '0123456789002', '90123', '2024-01-29', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(31, 'dsimmons765', '', 'dsimmons765@example.com', 'Daniel', 'Simmons', '0234567898765', '23456', '2026-02-22', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(32, 'amorris678', '', 'amorris678@example.com', 'Anna', 'Morris', '2345608907654', '34567', '2025-10-10', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(33, 'jgriffin234', '', 'jgriffin234@example.com', 'Jack', 'Griffin', '3406789012345', '45678', '2023-03-05', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(34, 'pwatson987', '', 'pwatson987@example.com', 'Patricia', 'Watson', '4067890123456', '56789', '2024-12-14', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(35, 'ljohnson432', '', 'ljohnson432@example.com', 'Laura', 'Johnson', '5078901234567', '67890', '2025-05-25', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(36, 'bray123', '', 'bray123@example.com', 'Brian', 'Ray', '6789012345608', '78901', '2026-09-10', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(37, 'skelly999', '', 'skelly999@example.com', 'Steven', 'Kelly', '7890023456789', '89012', '2023-02-01', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(38, 'oevans432', '', 'oevans432@example.com', 'Olivia', 'Evans', '8901034567890', '90123', '2025-12-31', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(39, 'kmills555', '', 'kmills555@example.com', 'Kevin', 'Mills', '9012305638901', '12345', '2023-08-22', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(40, 'tmorris678', '', 'tmorris678@example.com', 'Thomas', 'Morris', '2123456789012', '23456', '2024-11-05', 1, '2024-11-26 23:26:26', '2024-11-26 23:32:10'),
(41, 'jcox987', '', 'jcox987@example.com', 'Jessica', 'Cox', '123456782123', '34567', '2023-11-10', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(42, 'ssanders234', '', 'ssanders234@example.com', 'Sarah', 'Sanders', '2245678901234', '45678', '2025-02-18', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(43, 'swalker555', '', 'swalker555@example.com', 'Steve', 'Walker', '3456289012345', '56789', '2027-01-04', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(44, 'jthompson765', '', 'jthompson765@example.com', 'Jennifer', 'Thompson', '4567290123456', '67890', '2023-12-01', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(45, 'mdavis432', '', 'mdavis432@example.com', 'Mark', 'Davis', '5678901232567', '78901', '2025-04-22', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(46, 'hwright876', '', 'hwright876@example.com', 'Henry', 'Wright', '6789022345678', '89012', '2024-11-14', 1, '2024-11-26 23:26:26', '2024-11-26 23:30:43'),
(47, 'tdavis234', '', 'tdavis234@example.com', 'Tim', 'Davis', '7890123456289', '90123', '2025-08-17', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(48, 'gjones654', '', 'gjones654@example.com', 'George', 'Jones', '8901234267890', '12345', '2024-02-20', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(49, 'pfoster999', '', 'pfoster999@example.com', 'Paul', 'Foster', '9012342673901', '23456', '2026-05-09', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(50, 'kjones111', '', 'kjones111@example.com', 'Kate', 'Jones', '0123456782012', '34567', '2025-09-29', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(55, 'jdoe123', '', 'jdoe123@example.com', 'John', 'Doe', '1234567220123', '56789', '2025-12-31', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(56, 'mbrown789', '', 'mbrown789@example.com', 'Michael', 'Brown', '3456789012945', '78901', '2026-01-20', 1, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(57, 'asmith456', '', 'asmith456@example.com', 'Alice', 'Smith', '2345678901234', '67890', '2023-06-15', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26'),
(58, 'kparker321', '', 'kparker321@example.com', 'Karen', 'Parker', '4567690123456', '89012', '2022-09-11', 0, '2024-11-26 23:26:26', '2024-11-26 23:26:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pending_changes`
--
ALTER TABLE `pending_changes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `jmbg` (`jmbg`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pending_changes`
--
ALTER TABLE `pending_changes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pending_changes`
--
ALTER TABLE `pending_changes`
  ADD CONSTRAINT `pending_changes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
