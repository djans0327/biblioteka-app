<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}

$stmt = $conn->query('SELECT * FROM users');
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
    <style>
    #userChart {
        max-width: 800px; /* Maksimalna širina */
        max-height: 400px; /* Maksimalna visina */
        margin: auto; /* Centriranje */
    }
</style>
</head>
<body>
    <div class="admin-sidebar">
        <ul>
            <li><a href="#">Notifikacije</a></li>
            <li><a href="payments.php">Plaćanja</a></li>
            <li><a href="pending_requests.php">Zahtevi na čekanju</a></li>
            <li><a href="logout.php">Odjava</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <h2>Lista Korisnika</h2>
        <table>
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Prezime</th>
                    <th>JMBG</th>
                    <th>Broj FitPass kartice</th>
                    <th>Datum Isteka</th>
                    <th>Status</th>
                    <th>Akcija</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['name']) ?></td>
                    <td><?= htmlspecialchars($user['surname']) ?></td>
                    <td><?= htmlspecialchars($user['jmbg']) ?></td>
                    <td><?= htmlspecialchars($user['fitpass_number']) ?></td>
                    <td><?= htmlspecialchars($user['membership_valid_until']) ?></td>
                    <td><?= $user['blocked'] ? 'Blokiran' : 'Aktivan' ?></td>
                    <td><a href="edit_user.php?id=<?= $user['id'] ?>">Izmeni</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="admin-content">
    <h2>Statistika</h2>
    <div>
        <h3>Ukupni broj korisnika: <?php echo count($users); ?></h3>
        <canvas id="userChart" width="400" height="200"></canvas>
    </div>

    <?php
// Priprema podataka za statistiku
$stmt_active = $conn->prepare("SELECT COUNT(*) FROM users WHERE blocked = '0'");
$stmt_active->execute();
$active_users = $stmt_active->fetchColumn();

$stmt_inactive = $conn->prepare("SELECT COUNT(*) FROM users WHERE blocked = '1'");
$stmt_inactive->execute();
$inactive_users = $stmt_inactive->fetchColumn();

$stmt_expired = $conn->prepare("
    SELECT COUNT(*) 
    FROM users 
    WHERE membership_valid_until BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()
");
$stmt_expired->execute();
$expired_users = $stmt_expired->fetchColumn();
?>

<div class="admin-content">
    <h2></h2>
    <div>
        <h3>Aktivni korisnici: <?php echo $active_users; ?></h3>
        <h3>Neaktivni korisnici: <?php echo $inactive_users; ?></h3>
        <h3>Istekli u proslih mesec dana: <?php echo $expired_users; ?></h3>
    </div>
    <canvas id="userChart" width="400" height="200"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('userChart').getContext('2d');
    const userChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Aktivni korisnici', 'Neaktivni korisnici', 'Istekle u poslednje vreme'],
            datasets: [{
                data: [<?php echo $active_users; ?>, <?php echo $inactive_users; ?>, <?php echo $expired_users; ?>],
                backgroundColor: [
                    'rgba(59, 130, 246, 0.6)', // Plava za aktivne
                    'rgba(255, 99, 132, 0.6)', // Crvena za neaktivne
                    'rgba(255, 206, 86, 0.6)'  // Žuta za istekle
                ],
                borderColor: [
                    'rgba(59, 130, 246, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            }
        }
    });
</script>




</div>
</body> 
</html>
