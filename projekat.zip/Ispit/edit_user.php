<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}

if (!isset($_GET['id'])) {
    echo "<p class='text-danger'>ID korisnika nije prosleđen.</p>";
    exit;
}

$user_id = $_GET['id'];

// Dohvatanje podataka korisnika
$stmt = $conn->prepare('SELECT * FROM users WHERE id = :id');
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p class='text-danger'>Korisnik nije pronađen.</p>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $jmbg = $_POST['jmbg'];
    $fitpass_number = $_POST['fitpass_number'];
    $membership_valid_until = $_POST['membership_valid_until'];
    $blocked = isset($_POST['blocked']) ? 1 : 0;

    $stmt = $conn->prepare('UPDATE users SET name = :name, surname = :surname, jmbg = :jmbg, fitpass_number = :fitpass_number, membership_valid_until = :membership_valid_until, blocked = :blocked, updated_at = NOW() WHERE id = :id');
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':surname', $surname);
    $stmt->bindParam(':jmbg', $jmbg);
    $stmt->bindParam(':fitpass_number', $fitpass_number);
    $stmt->bindParam(':membership_valid_until', $membership_valid_until);
    $stmt->bindParam(':blocked', $blocked);
    $stmt->bindParam(':id', $user_id);
    $stmt->execute();

    header('Location: admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izmena Korisnika</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <ul>
            <li><a href="admin.php">Nazad</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <h2>Izmena Korisnika</h2>
        <form method="POST">
            <label for="name">Ime:</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
            <label for="surname">Prezime:</label>
            <input type="text" id="surname" name="surname" value="<?= htmlspecialchars($user['surname']) ?>" required>
            <label for="jmbg">JMBG:</label>
            <input type="text" id="jmbg" name="jmbg" value="<?= htmlspecialchars($user['jmbg']) ?>" required>
            <label for="fitpass_number">Broj Fit Passa:</label>
            <input type="text" id="fitpass_number" name="fitpass_number" value="<?= htmlspecialchars($user['fitpass_number']) ?>" required>
            <label for="membership_valid_until">Datum Isteka Članarine:</label>
            <input type="date" id="membership_valid_until" name="membership_valid_until" value="<?= htmlspecialchars($user['membership_valid_until']) ?>" required>
            <label for="blocked">Blokiran:</label>
            <input type="checkbox" id="blocked" name="blocked" <?= $user['blocked'] ? 'checked' : '' ?>>
            <button type="submit">Sačuvaj</button>
        </form>
    </div>
</body>
</html>
