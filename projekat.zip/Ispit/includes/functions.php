<?php
function fetchUserById($conn, $id) {
    $stmt = $conn->prepare('SELECT * FROM users WHERE id = :id');
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function fetchAllUsers($conn) {
    $stmt = $conn->query('SELECT * FROM users');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function fetchAdminById($conn, $id) {
    $stmt = $conn->prepare('SELECT * FROM admins WHERE id = :id');
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function insertPendingChange($conn, $userId, $field, $oldValue, $newValue) {
    $stmt = $conn->prepare('INSERT INTO pending_changes (user_id, field_name, old_value, new_value, status) VALUES (:user_id, :field, :old_value, :new_value, "pending")');
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':field', $field);
    $stmt->bindParam(':old_value', $oldValue);
    $stmt->bindParam(':new_value', $newValue);
    $stmt->execute();
}
?>
