<?php
session_start();
require 'includes/db.php';

// Provera da li je korisnik admin
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Dohvatanje zahteva na čekanju
$stmt = $conn->query('SELECT pc.id, u.name, u.surname, pc.field_name, pc.old_value, pc.new_value, pc.status 
                      FROM pending_changes pc 
                      JOIN users u ON pc.user_id = u.id 
                      WHERE pc.status = "pending"');
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];

    if ($action === 'approve') {
        $stmt = $conn->prepare('UPDATE pending_changes SET status = "approved" WHERE id = :id');
    } elseif ($action === 'reject') {
        $stmt = $conn->prepare('UPDATE pending_changes SET status = "rejected" WHERE id = :id');
    }

    $stmt->bindParam(':id', $request_id);
    $stmt->execute();

    header('Location: pending_requests.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zahtevi na Čekanju</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <ul>
            <li><a href="admin.php">Povratak na Admin Panel</a></li>
            <li><a href="payments.php">Plaćanja</a></li>
            <li><a href="pending_requests.php">Zahtevi na Čekanju</a></li>
            <li><a href="logout.php">Odjava</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <h2>Zahtevi na Čekanju</h2>
        <table>
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Prezime</th>
                    <th>Polje</th>
                    <th>Stara Vrednost</th>
                    <th>Nova Vrednost</th>
                    <th>Akcije</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['name']) ?></td>
                    <td><?= htmlspecialchars($request['surname']) ?></td>
                    <td><?= htmlspecialchars($request['field_name']) ?></td>
                    <td><?= htmlspecialchars($request['old_value']) ?></td>
                    <td><?= htmlspecialchars($request['new_value']) ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                            <button type="submit" name="action" value="approve">Odobri</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                            <button type="submit" name="action" value="reject">Odbij</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
