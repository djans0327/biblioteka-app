<?php
session_start();
require 'includes/db.php';

// Provera da li je korisnik admin
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['user_id'])) {
    die('Korisnik nije prosleđen.');
}

$user_id = $_GET['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_date = $_POST['payment_date'];
    $amount = $_POST['amount'];

    $stmt = $conn->prepare('INSERT INTO payments (user_id, payment_date, amount) VALUES (:user_id, :payment_date, :amount)');
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':payment_date', $payment_date);
    $stmt->bindParam(':amount', $amount);
    $stmt->execute();

    header('Location: payments.php');
    exit;
}

// Dohvatanje korisnika
$stmt = $conn->prepare('SELECT name, surname FROM users WHERE id = :user_id');
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj Uplatu</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <ul>
            <li><a href="payments.php">Povratak na Plaćanja</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <h2>Dodaj Uplatu za <?= htmlspecialchars($user['name']) ?> <?= htmlspecialchars($user['surname']) ?></h2>
        <form method="POST">
            <label for="payment_date">Datum Uplate:</label>
            <input type="date" id="payment_date" name="payment_date" required>
            <label for="amount">Iznos:</label>
            <input type="number" step="0.01" id="amount" name="amount" required>
            <button type="submit">Sačuvaj</button>
        </form>
    </div>
</body>
</html>
