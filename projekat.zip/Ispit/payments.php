<?php
session_start();
require 'includes/db.php';

// Provera da li je korisnik admin
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Dohvatanje korisnika i njihovih uplata
$stmt = $conn->query("
    SELECT u.id AS user_id, u.name, u.surname, u.jmbg, u.fitpass_number, p.payment_date, p.amount 
    FROM users u 
    LEFT JOIN payments p ON u.id = p.user_id 
    ORDER BY u.name ASC
");
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plaćanja</title>
    <link rel="stylesheet" href="/Ispit/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <ul>
            <li><a href="admin.php">Povratak na Admin Panel</a></li>
            <li><a href="payments.php">Plaćanja</a></li>
            <li><a href="pending_requests.php">Zahtevi na Čekanju</a></li>
            <li><a href="logout.php">Odjava</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <h2>Plaćanja</h2>
        <table>
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Prezime</th>
                    <th>JMBG</th>
                    <th>Broj FitPass kartice</th>
                    <th>Datum Uplate</th>
                    <th>Iznos</th>
                    <th>Dodaj Uplatu</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><?= htmlspecialchars($payment['name']) ?></td>
                    <td><?= htmlspecialchars($payment['surname']) ?></td>
                    <td><?= htmlspecialchars($payment['jmbg']) ?></td>
                    <td><?= htmlspecialchars($payment['fitpass_number']) ?></td>
                    <td><?= htmlspecialchars($payment['payment_date']) ?: 'Nema uplata' ?></td>
                    <td><?= htmlspecialchars($payment['amount']) ?: '0.00' ?></td>
                    <td>
                        <a href="add_payment.php?user_id=<?= $payment['user_id'] ?>" class="btn btn-primary">Dodaj</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
