<?php
session_start();
require 'includes/db.php';

// Provera da li je korisnik prijavljen i da nije admin
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Dohvatanje korisničkih podataka
$stmt = $conn->prepare('SELECT * FROM users WHERE id = :id');
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p class='text-danger'>Korisnik nije pronađen.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Korisnički Profil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background-image: url('/uploads/loginbackground.png'); background-size: cover;">
    <div class="user-sidebar">
        <ul>
            <li><a href="user.php">Profil</a></li>
            <li><a href="edit_profile.php">Izmeni Profil</a></li>
            <li><a href="logout.php">Odjava</a></li>
        </ul>
    </div>
    <div class="user-content">
        <h2>Vaš Profil</h2>
        <table>
            <tr>
                <th>Ime:</th>
                <td><?= htmlspecialchars($user['name']) ?></td>
            </tr>
            <tr>
                <th>Prezime:</th>
                <td><?= htmlspecialchars($user['surname']) ?></td>
            </tr>
            <tr>
                <th>JMBG:</th>
                <td><?= htmlspecialchars($user['jmbg']) ?></td>
            </tr>
            <tr>
                <th>Broj FitPass Kartice:</th>
                <td><?= htmlspecialchars($user['fitpass_number']) ?></td>
            </tr>
            <tr>
                <th>Datum Isteka FitPass kartice:</th>
                <td><?= htmlspecialchars($user['membership_valid_until']) ?></td>
            </tr>
            <tr>
                <th>Status:</th>
                <td><?= $user['blocked'] ? 'Blokiran' : 'Aktivan' ?></td>
            </tr>
        </table>
    </div>
</body>
</html>
