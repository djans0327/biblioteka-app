<?php
session_start();
require 'includes/db.php';

// Proveri korisničku sesiju
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Dohvati podatke korisnika
$stmt = $conn->prepare('SELECT * FROM users WHERE id = :id');
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p>Greška: korisnik nije pronađen.</p>";
    exit;
}

// Proveri da li je zahtev POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Preuzmi podatke iz forme
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $jmbg = $_POST['jmbg'];
        $fitpass_number = $_POST['fitpass_number'];
        $membership_valid_until = $_POST['membership_valid_until'];

        // Polja koja se ažuriraju
        $fields = [
            'name' => [$user['name'], $name],
            'surname' => [$user['surname'], $surname],
            'jmbg' => [$user['jmbg'], $jmbg],
            'fitpass_number' => [$user['fitpass_number'], $fitpass_number],
            'membership_valid_until' => [$user['membership_valid_until'], $membership_valid_until],
        ];

        // Transakcija za unos promena
        $conn->beginTransaction();
        $stmt = $conn->prepare('INSERT INTO pending_changes (user_id, field_name, old_value, new_value, status) 
                                VALUES (:user_id, :field_name, :old_value, :new_value, "pending")');

        foreach ($fields as $field => [$oldValue, $newValue]) {
            if ($oldValue !== $newValue) { // Samo ako ima promene
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':field_name', $field, PDO::PARAM_STR);
                $stmt->bindParam(':old_value', $oldValue, PDO::PARAM_STR);
                $stmt->bindParam(':new_value', $newValue, PDO::PARAM_STR);
                $stmt->execute();
            }
        }
        $conn->commit();

        echo "<p>Zahtev za promenu je poslat na odobrenje.</p>";
    } catch (PDOException $e) {
        $conn->rollBack();
        echo "<p>Greška: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izmeni Profil</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .container-fluid { margin-left: 300px; }
        form div { padding: 8px; }
        form div input { padding: 5px; height: 20px; border-radius: 8px; }
        #back { padding: 10px; border: 1px solid white; text-decoration: none; background-color: #3b5323; border-radius: 8px; color: white; font-size: 15px; }
    </style>
</head>
<body style="background-image: url('/uploads/loginbackground.png'); background-size: cover; background-position: center;">
<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light user-sidebar">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="user.php"><i class="fas fa-user"></i> Profil</a></li>
                <li class="nav-item"><a class="nav-link active" href="edit_profile.php"><i class="fas fa-edit"></i> Izmeni Profil</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Odjava</a></li>
            </ul>
        </nav>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 user-main-content">
            <h2 class="mt-5">Izmeni Profil</h2>
            <form method="POST" class="user-form">
                <div class="form-group">
                    <label for="name">Ime</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="surname">Prezime</label>
                    <input type="text" class="form-control" id="surname" name="surname" value="<?= htmlspecialchars($user['surname']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="jmbg">JMBG</label>
                    <input type="text" class="form-control" id="jmbg" name="jmbg" value="<?= htmlspecialchars($user['jmbg']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="fitpass_number">Broj FitPass kartice</label>
                    <input type="text" class="form-control" id="fitpass_number" name="fitpass_number" value="<?= htmlspecialchars($user['fitpass_number']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="membership_valid_until">Datum isteka Fitpass kartice</label>
                    <input type="date" class="form-control" id="membership_valid_until" name="membership_valid_until" value="<?= htmlspecialchars($user['membership_valid_until']) ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Sačuvaj Izmene</button>
                <a href="user.php" id="back" class="btn btn-secondary">Nazad</a>
            </form>
        </main>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
