
export interface ActorModel {
    actorId: number;
    name: string;
    createdAt: string;
}

