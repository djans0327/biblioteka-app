
export interface GenreModel {
    genreId: number;
    name: string;
    createdAt: string;
}

