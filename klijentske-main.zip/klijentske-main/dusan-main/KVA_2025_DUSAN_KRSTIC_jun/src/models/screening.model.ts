
export interface ScreeningModel {
    id: number;
    movieId: number;
    date: string;
    time: string;
    hall: string;
    price: number;
    availableSeats: number;
}
