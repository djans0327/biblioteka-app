import {
  MatDivider,
  MatDividerModule
} from "./chunk-2KNY3RB6.js";
import "./chunk-SVVIGFXE.js";
import "./chunk-GAS42O4O.js";
import "./chunk-C5KSE33A.js";
import "./chunk-Z6SHPYE2.js";
import "./chunk-AOU3XVX2.js";
import "./chunk-4UKKW2LS.js";
import "./chunk-LMKDXKLH.js";
import "./chunk-4ULMLRGT.js";
export {
  MatDivider,
  MatDividerModule
};
